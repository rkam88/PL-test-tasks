public class State {
    private int time;
    private int currentCustomers;

    public State() {
        currentCustomers = 0;
    }
}

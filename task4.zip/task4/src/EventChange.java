public enum EventChange {
    ENTRY,
    EXIT
}
